import{c as o}from"./GcR2fieI.js";var n=o("outline","chevron-down","ChevronDown",[["path",{d:"M6 9l6 6l6 -6",key:"svg-0"}]]);export{n as I};
