import{c as e}from"./qqqfUOwc.js";var r=e("outline","chevron-right","ChevronRight",[["path",{d:"M9 6l6 6l-6 6",key:"svg-0"}]]);export{r as I};
