import{d as t,bw as r}from"./index-BklDWftz.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
