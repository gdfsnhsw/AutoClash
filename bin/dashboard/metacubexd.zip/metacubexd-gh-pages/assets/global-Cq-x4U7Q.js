import{W as a,a$ as m}from"./index-DACeLBg-.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
