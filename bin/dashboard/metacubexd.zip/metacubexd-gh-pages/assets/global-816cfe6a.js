import{_ as a}from"./vendor-cf28f096.js";import{a8 as m}from"./index-d35d476a.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
