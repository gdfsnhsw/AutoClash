import{d as t,bC as r}from"./index-8p10MaTT.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
