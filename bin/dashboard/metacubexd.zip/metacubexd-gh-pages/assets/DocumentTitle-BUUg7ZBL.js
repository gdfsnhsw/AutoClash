import{f as t,bB as r}from"./index-CF0nzQpL.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
