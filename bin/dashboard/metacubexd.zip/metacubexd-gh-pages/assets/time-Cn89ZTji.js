import{Z as a,b8 as m}from"./index-BPVK8l7-.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
