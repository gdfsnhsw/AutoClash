import{Y as a}from"./vendor-LFOJg3vZ.js";import{ad as m}from"./index-cYOqtyO9.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
