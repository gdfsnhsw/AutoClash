import{W as a,aZ as m}from"./index-BTewGE2y.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
