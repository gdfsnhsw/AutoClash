import{d as t,bB as r}from"./index-k2nmBVNN.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
