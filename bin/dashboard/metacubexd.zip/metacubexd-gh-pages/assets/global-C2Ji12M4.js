import{V as a,b2 as m}from"./index-DlC9LO27.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
