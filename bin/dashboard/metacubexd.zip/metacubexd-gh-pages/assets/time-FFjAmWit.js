import{W as a,a_ as m}from"./index-CWCcHU9x.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
