import{W as a,b2 as m}from"./index-B45ObzUn.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
