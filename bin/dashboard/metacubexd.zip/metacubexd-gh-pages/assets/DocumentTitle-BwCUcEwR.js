import{f as t,bA as r}from"./index-1340Lhow.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
