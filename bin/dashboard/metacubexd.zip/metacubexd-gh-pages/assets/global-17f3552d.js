import{_ as a}from"./vendor-ec1fbc1a.js";import{a8 as m}from"./index-57f146ce.js";const s=o=>a(o).locale(m()).fromNow();export{s as f};
