import{d as t,bx as r}from"./index-B2UtOO5P.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
